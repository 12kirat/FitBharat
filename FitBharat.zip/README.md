# FitBharat

Simple Indian diet planner with Hindi + English UI.