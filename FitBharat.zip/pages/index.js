export default function Home() {
  return (
    <div className="p-4">
      <h1 className="text-xl font-bold text-center">🍽️ Welcome to FitBharat</h1>
      <p className="text-center text-sm text-gray-600">Your daily Indian diet plan - Hindi + English</p>
    </div>
  );
}